#!/usr/bin/env python3
# -*- coding: utf-8 -*-

print("I'm a new firmware!")
